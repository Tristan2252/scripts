             === PERSONAL PHONE BOOK PROGRAM ===
 * about
 
      >>> PERSONAL CONTACTS PROGRAM                 <<<
      >>> Developed By: Tristan Vigil for CSE-107   <<<
      >>> Date created: March 12th 2015             <<<
      
 * Description
    
     Program is designed to create a personal phone book
     for the user to add contacts to to remember phone
     numbers, email, and companies
     
     The program allow the user to edit, remove, view,
     add, import, and save contacts to the phone book.
     
     Basic command can be found below and when the program
     starts. Or by typing "menu" as a command.'
     
     type:"
     "-------------------------------------------------------------------------"
     " * 'save' to save your contacts          * 'add' to add contacts"
     " * 'edit' to edit a contact              * 'remove' to remove a contact"
     " * 'view' to view a list of contacts     * 'exit' to close the program"
     " * 'menu' to review the menu             * 'about' to view developer info"
     " * 'import' it import contacts from .csv file"
     "-------------------------------------------------------------------------"
     
     The "back" command can be used in the sub-menu's to navigate back
     to main menu.
