""" 1. Given two fractions as tuples, multiply them.
    2. Given two fractions as tuples, divide them.
    3. Given a list of fractions as a tuple, return the one that is smallest in value."""


def mult(fraction1, fraction2):
    a, b = fraction1  # splits fraction into individual values
    x, y = fraction2
    totalnum = a * x  # multiples split values together
    totaldenom = b * y
    return "Multiplication of the fractions: {}/{} ".format(totalnum, totaldenom)


def divide(fraction1, fraction2):
    a, b = fraction1  # splits fraction into individual values
    x, y = fraction2
    totalnum = a * y  # multiples split values together
    totaldenom = b * x
    return "Division of the first by the second: {}/{}".format(totalnum, totaldenom)


def small(fractions):
    answer = fractions[0]  # sets answer to first index in fractions
    for frac in fractions:
        deci = frac[0] / frac[1]  # finds the decimal value for each tuple in the list
        min = answer[0] / answer[1]  # current minimum fraction stored here (also in decimal form)
        print("Smallest is currently: {}".format(min))  # showing work
        if deci < min:  # if the decimal of the next fraction is bigger than min, set answer to frac
            answer = frac
    return "The smallest fraction is {} / {}".format(answer[0], answer[1])


def main():
    # frac1 = (5, 3) # test numbers
    # frac2 = (10, 3)

    num1 = int(input("Enter numerator 1: "))
    denom1 = int(input("Enter denominator 1: "))
    frac1 = (num1, denom1)  # fraction one

    num2 = int(input("Enter numerator 2: "))
    denom2 = int(input("Enter denominator 2: "))
    frac2 = (num2, denom2)  # fraction two

    print()
    print("== Multiplication and Division ==\n")
    print(mult(frac1, frac2))
    print(divide(frac1, frac2))

    print('== Smallest fraction ==\n'
          '-- Type values for numerators and denominators for fractions --\n'
          '             -- To stop program type exit --')

    fractions = []  # empty list to put fractions in
    ext_loop = False
    while not ext_loop:
        add_num = input("Enter numerator: ")
        #  add_num comes first so that the user doesnt get prompted for denominator after exit is typed
        if add_num == "exit":
            print()
            print(small(fractions))
            ext_loop = True
        else:
            add_denom = input("Enter denominator: ")
            fractions.append((int(add_num), int(add_denom)))  # adds imputed values to list


if __name__ == "__main__":
    main()