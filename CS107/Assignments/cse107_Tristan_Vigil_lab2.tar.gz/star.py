import turtle

counter = 0  # used to exit while loop

while counter < 5:
    turtle.forward(200)
    turtle.right(144)
    counter = counter + 1

number = input("type any key to stop: ")